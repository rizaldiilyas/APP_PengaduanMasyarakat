<?php
$con = mysqli_connect('localhost','root','','pengaduan_masyarakat')
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaduan Masyarakat</title>
    <link rel="stylesheet" href="Login.css">
    <link rel="stylesheet" href="https;//cdnjs.cloudflare.com/ajax/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
    <div class="login-box">
        <h2>Login</h2>
        <form action="" method="post">
          <div class="user-box">
            <input type="text" name="Email" required>
            <label>Email</label>
          </div>
          <div class="user-box">
            <input type="password" name="Password" required>
            <label>Password</label>
          </div>
          <a href="navbar.php" type="submit">
            <span></span>
            Submit
          </a>
          <a href="Register.php">
            Register
          </a>
        </form>
      </div>
</body>
</html>