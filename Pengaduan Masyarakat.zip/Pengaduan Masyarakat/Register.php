<?php
$con = mysqli_connect('localhost','root','','pengaduan_masyarakat',)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Login.css">
</head>
<body>
    <div class="login-box">
        <h2>Register</h2>
        <form>
          <div class="user-box">
            <input type="text" name="" required="">
            <label>Nama Depan</label>
          </div>
          <div class="user-box">
            <input type="password" name="" required="">
            <label>Nama Belakang</label>
          </div>
          <div class="user-box">
          <input type="text" name="" required="">
          <label>Email</label>
        </div>
        <div class="user-box">
            <input type="text" name="" required="">
            <label>Password</label>
          </div>
          <a href="navbar.php">
            Submit
          </a>
          <a href="Login.php">
            Login
          </a>    
</body>
</html>
