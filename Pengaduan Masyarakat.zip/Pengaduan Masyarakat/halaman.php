<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
    <center>
        <h1>ISI LAPORAN MASYARAKAT</h1>
    </center>
    <center>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Example textarea</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" style="border: none;border-bottom: 1px solid black; background: none;outline: none;"></textarea>
          </div>
    </center>
    <center>
        <label for="myfile">Select a file:</label>
        <input type="file" id="myfile" name="myfile">
    </center>
    <div id="mySidenav" class="sidenav">
        <img src="./Image/Admin.jpg" alt="" style="position: absolute; top: 0; width: 100px;" >
        <br>
        k                                                                         ..        <br>
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="position: absolute;">Setting</a>
        <img src="./Image/Admin.jpg" alt="" style="width: 30px;position: relative;top: -20px;left: 80px;">
        <br>
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="position: absolute;">Account</a>
        <img src="./Image/Admin.jpg" alt="" style="width: 30px;position: relative;top: -20px;left: 80px;">
        <br>
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="position: absolute;">Contact</a>
        <img src="./Image/Admin.jpg" alt="" style="width: 30px;position: relative;top: -20px;left: 80px;">
        <br>
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="position: absolute;">Log out</a>
        <img src="./Image/Admin.jpg" alt="" style="width: 30px;position: relative;top: -20px;left: 80px;">
        <br>
      </div>
      
      <!-- Use any element to open the sidenav -->
      <span onclick="openNav()">open</span>
      
      <!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page -->
      <div id="main">
        ...
      </div>
</body>
</html>