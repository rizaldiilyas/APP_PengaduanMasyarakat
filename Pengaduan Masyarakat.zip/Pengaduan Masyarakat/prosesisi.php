<php
$isi = $_POST['isi_laporan'];

$nama_foto = $_FILES['foto']['name'];
$asal_foto = $_FILES['foto']['tmp_foto'];

$koneksi =  mysqli_connect('loclahost','root','','web_pengaduan_masyarakat');
if(!$kkoneksi){
    echo "gagal";
}
$Id_Pengaduan = ;
$Tgl_Pengaduan = ;
$NIK = ;
$Isi_Laporan = ;
$Foto = ;
$status = ;
$result = $koneksi->("INSERT INTO 'pengaduan(Id_Pengaduan, Tgl_Pengaduan, NIK, Foto, status) VALUES ('ta')'")
if($result){
    move_upload_file($asal_foto, "foto/$nama_foto");
    header("Location:infofile.php");
}
?>